import Header from "@/component/Header";
import Hero from "@/component/Hero";
import Category from "@/component/Category";
import News from "@/component/News";
import Data from "@/data/data.json";
import Profile from "@/component/Profile";

export default function index() {
  return (
    <>
      <Header />
      <Hero data={Data.hero} />
      <Category categories={Data.categories} />
      <News news={Data.articles} />
      <Profile about={Data.about} />
    </>
  );
}

import Nav from "./Nav"

const header = () => {
  return (
      <header>
          <Nav/>
    </header>
  )
}

export default header
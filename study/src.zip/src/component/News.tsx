import Link from "next/link";
import style from "@/component/News.module.scss";
import Image from "next/image";

type articleItem = {
  imageUrl: string;
  title: string;
  date: string;
  link: string;
};

type NewsProps = {
  news: {
    title: string;
    article: articleItem[];
  };
};

const News = ({ news }: NewsProps) => {
  return (
    <div className={style.article}>
      <h2>{news.title}</h2>
      <div className={style.articleContent}>
        {news.article.map((item, i) => (
          <div className={style.articleContentItem} key={i}>
            <div className={style.articleImage}>
              <Image
                src={item.imageUrl}
                alt={item.title}
                width={300}
                height={200}
              />
            </div>
            <div className={style.articleText}>
              <h3>{item.title}</h3>
              <p>{item.date}</p>
              <Link href={item.link}>続きを読む</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default News;
